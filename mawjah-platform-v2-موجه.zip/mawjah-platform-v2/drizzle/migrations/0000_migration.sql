create extension if not exists vector with schema extensions;

create table public.knowledge_chunks (
  id uuid primary key default gen_random_uuid(),
  source text not null,
  section text not null default '',
  content text not null,
  embedding extensions.vector,
  created_at timestamptz not null default now()
);
grant select on public.knowledge_chunks to anon, authenticated;
grant all on public.knowledge_chunks to service_role;
alter table public.knowledge_chunks enable row level security;
create policy "knowledge readable" on public.knowledge_chunks for select to anon, authenticated using (true);

create or replace function public.match_knowledge(query_embedding extensions.vector, match_count int default 3)
returns table(source text, section text, content text, similarity float)
language sql stable set search_path = public, extensions as $$
  select source, section, content, 1 - (embedding <=> query_embedding) as similarity
  from public.knowledge_chunks
  where embedding is not null and vector_dims(embedding) = vector_dims(query_embedding)
  order by embedding <=> query_embedding
  limit least(match_count, 8);
$$;
grant execute on function public.match_knowledge to anon, authenticated, service_role;

create table public.certificates (
  id uuid primary key default gen_random_uuid(),
  certificate_number text not null unique,
  title text not null,
  owner_name text not null,
  sha256_hash text not null,
  created_at timestamptz not null default now()
);
grant select on public.certificates to anon, authenticated;
grant all on public.certificates to service_role;
alter table public.certificates enable row level security;
create policy "certificates verifiable" on public.certificates for select to anon, authenticated using (true);

insert into public.knowledge_chunks (source, section, content) values
('مقترح موجة V2','الحالة','منصة موجة V2 مقترح تقني داخلي للتقييم، وليست اعتمادًا حكوميًا رسميًا، ولا توجد شراكة أو ربط حكومي مثبت. معرّف الوثيقة DOC-MWG-2026-005-FULL وصاحب المقترح مزيد هايف الرفعان الرشيدي.'),
('مقترح موجة V2','التعريف','موجة حاضنة أفكار للقطاع الحكومي والخدمي، تجمع الإيداع الرقمي، الشهادة، التحليل الذكي، والمراجعة البشرية.'),
('مقترح موجة V2','الأهداف','أهداف مقترحة وليست نتائج مثبتة: تقليل وقت معالجة المستندات والطلبات حتى 70%، لوحات مؤشرات وتحليلات، وسيادة رقمية على البيانات.'),
('مقترح موجة V2','حالات الاستخدام','حالات الاستخدام: معالجة المستندات والتعاميم؛ أتمتة خدمة المستفيدين وفرز وتحليل الطلبات والشكاوى؛ مساعد المعرفة المؤسسية Enterprise Knowledge Base لاسترجاع اللوائح والسياسات.'),
('مقترح موجة V2','المراجعة البشرية','لا يُتخذ أي قرار حساس نهائيًا تلقائيًا. التحليل الذكي أولي فقط، ويلزم مراجعة واعتماد الموظف المختص ثم تسجيل القرار للتدقيق (Human-in-the-Loop).'),
('مقترح موجة V2','التقنيات','أسماء النماذج والأدوات الخارجية مثل Gemini وDeepSeek وChromaDB وصف تقني مقترح فقط ولا تثبت شراكة أو اعتمادًا.'),
('مقترح موجة V2','البصمة','البصمة الرقمية SHA-256 للوثيقة: 7f83b1657ff1fc53b92dc18148a1d65dfc2d4b1fa9d69184163d76e793784a69. المطابقة تثبت تطابق المحتوى فقط ولا تثبت ملكية قانونية أو توقيعًا تشفيريًا معتمدًا.'),
('مرجع الامتثال','PDPL','نظام حماية البيانات الشخصية PDPL في المملكة يتطلب أساسًا نظاميًا للمعالجة، تقليل البيانات، إشعار أصحاب البيانات، وحماية النقل خارج المملكة. يلزم التحقق من النص الرسمي لدى سدايا.'),
('مرجع الامتثال','NCA','الضوابط الأساسية للأمن السيبراني NCA ECC تغطي الحوكمة، إدارة الهويات والصلاحيات، حماية البيانات، المراقبة والاستجابة للحوادث. يلزم الرجوع للهيئة الوطنية للأمن السيبراني.'),
('مرجع الامتثال','SDAIA','مبادئ سدايا لأخلاقيات الذكاء الاصطناعي: النزاهة، الخصوصية، الشفافية، المساءلة، والإشراف البشري.');