import { createFileRoute } from "@tanstack/react-router";
import { slides } from "@/components/presentation/slides";
import { DeckShell } from "@/components/presentation/deck-shell";

const slide = slides[6];

export const Route = createFileRoute("/digital-doc")({
  head: () => ({ meta: [
    { title: "التوثيق الرقمي | منصة موجة V2" },
    { name: "description", content: slide.description },
    { property: "og:title", content: "موجة V2 — التوثيق الرقمي" },
    { property: "og:description", content: slide.description },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: DigitalDocPage,
});

function DigitalDocPage() {
  return <DeckShell active={6} />;
}
