import { createFileRoute } from "@tanstack/react-router";
import { slides } from "@/components/presentation/slides";
import { DeckShell } from "@/components/presentation/deck-shell";

const slide = slides[3];

export const Route = createFileRoute("/architecture")({
  head: () => ({ meta: [
    { title: "المكونات المعمارية | منصة موجة V2" },
    { name: "description", content: slide.description },
    { property: "og:title", content: "موجة V2 — المكونات المعمارية" },
    { property: "og:description", content: slide.description },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: ArchitecturePage,
});

function ArchitecturePage() {
  return <DeckShell active={3} />;
}
