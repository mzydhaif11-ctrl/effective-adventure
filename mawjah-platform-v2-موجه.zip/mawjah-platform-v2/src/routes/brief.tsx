import { createFileRoute } from "@tanstack/react-router";
import { slides } from "@/components/presentation/slides";
import { DeckShell } from "@/components/presentation/deck-shell";

const slide = slides[1];

export const Route = createFileRoute("/brief")({
  head: () => ({ meta: [
    { title: "الملخص التنفيذي | منصة موجة V2" },
    { name: "description", content: slide.description },
    { property: "og:title", content: "موجة V2 — الملخص التنفيذي" },
    { property: "og:description", content: slide.description },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: BriefPage,
});

function BriefPage() {
  return <DeckShell active={1} />;
}
