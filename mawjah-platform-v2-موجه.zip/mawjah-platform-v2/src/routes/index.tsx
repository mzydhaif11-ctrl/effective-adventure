import { createFileRoute } from "@tanstack/react-router";
import { slides, SlideContent } from "@/components/presentation/slides";
import { DeckShell } from "@/components/presentation/deck-shell";

export const Route = createFileRoute("/")({
  validateSearch: (search: Record<string, unknown>) => ({ print: search["print"] === true || search["print"] === "true" }),
  head: () => ({ meta: [
    { title: "عرض المشروع | منصة موجة V2" },
    { name: "description", content: "عرض تقديمي لمقترح موجة: الأهداف وحالات الاستخدام والحوكمة والتوثيق الرقمي SHA-256. توثيق داخلي للتقييم." },
    { property: "og:title", content: "موجة V2 — عرض المشروع" },
    { property: "og:description", content: "فكرة وطنية طموحة تبدأ بنموذج أولي. مقترح تقني داخلي للتقييم." },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Index,
});

function Index() {
  const { print } = Route.useSearch();
  if (print) return <main className="print-deck">{slides.map((slide, i) => <div key={slide.id} className="print-slide"><SlideContent index={i} /></div>)}</main>;
  return <DeckShell active={0} />;
}
