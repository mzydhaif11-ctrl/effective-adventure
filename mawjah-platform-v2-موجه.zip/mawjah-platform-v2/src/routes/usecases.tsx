import { createFileRoute } from "@tanstack/react-router";
import { slides } from "@/components/presentation/slides";
import { DeckShell } from "@/components/presentation/deck-shell";

const slide = slides[4];

export const Route = createFileRoute("/usecases")({
  head: () => ({ meta: [
    { title: "حالات الاستخدام | منصة موجة V2" },
    { name: "description", content: slide.description },
    { property: "og:title", content: "موجة V2 — حالات الاستخدام" },
    { property: "og:description", content: slide.description },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: UsecasesPage,
});

function UsecasesPage() {
  return <DeckShell active={4} />;
}
