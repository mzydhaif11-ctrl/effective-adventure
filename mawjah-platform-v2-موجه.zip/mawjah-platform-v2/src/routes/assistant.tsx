import { createFileRoute } from "@tanstack/react-router";
import { DeckShell } from "@/components/presentation/deck-shell";
import { MawjahAssistant } from "@/components/mawjah-assistant";

export const Route = createFileRoute("/assistant")({
  head: () => ({ meta: [
    { title: "المساعد الذكي | منصة موجة V2" },
    { name: "description", content: "مساعد موجة الذكي للمقترح والحوكمة والمراجعة البشرية في محادثة للجلسة الحالية." },
    { property: "og:title", content: "موجة V2 — المساعد الذكي" },
    { property: "og:description", content: "محادثة مع مساعد موجة حول المقترح والمعرفة المؤسسية والحوكمة." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: AssistantPage,
});

function AssistantPage() {
  return <DeckShell><MawjahAssistant /></DeckShell>;
}
