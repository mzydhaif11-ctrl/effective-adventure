import { createFileRoute } from "@tanstack/react-router";
import { slides } from "@/components/presentation/slides";
import { DeckShell } from "@/components/presentation/deck-shell";

const slide = slides[5];

export const Route = createFileRoute("/human-review")({
  head: () => ({ meta: [
    { title: "المراجعة البشرية | منصة موجة V2" },
    { name: "description", content: slide.description },
    { property: "og:title", content: "موجة V2 — المراجعة البشرية" },
    { property: "og:description", content: slide.description },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: HumanReviewPage,
});

function HumanReviewPage() {
  return <DeckShell active={5} />;
}
