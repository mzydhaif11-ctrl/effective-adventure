import { createFileRoute } from "@tanstack/react-router";
import { slides } from "@/components/presentation/slides";
import { DeckShell } from "@/components/presentation/deck-shell";

const slide = slides[7];

export const Route = createFileRoute("/status")({
  head: () => ({ meta: [
    { title: "حالة الوثيقة | منصة موجة V2" },
    { name: "description", content: slide.description },
    { property: "og:title", content: "موجة V2 — حالة الوثيقة" },
    { property: "og:description", content: slide.description },
    { property: "og:type", content: "website" }, { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: StatusPage,
});

function StatusPage() {
  return <DeckShell active={7} />;
}
