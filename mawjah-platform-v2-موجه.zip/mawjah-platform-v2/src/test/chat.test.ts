import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { KnowledgeLookupError, chatErrorMessage } from "@/lib/chat-error";

const mocks = vi.hoisted(() => ({ lookup: vi.fn(), createCall: vi.fn() }));
vi.mock("@/lib/memory.server", () => ({ getContextForPrompt: mocks.lookup }));
vi.mock("@/lib/ai/responses.server", () => ({ createResponsesCall: mocks.createCall }));
import { handleChat } from "@/lib/chat.server";

function request(messages: unknown[]) {
  return new Request("http://localhost:8080/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages }) });
}

describe("Assistant retrieval and conversation", () => {
  beforeEach(() => {
    vi.stubEnv("LOVABLE_API_KEY", "test-only");
    mocks.lookup.mockReset();
    mocks.createCall.mockReset();
    mocks.createCall.mockReturnValue({ response: async () => new Response("test stream") });
  });
  afterEach(() => vi.unstubAllEnvs());

  it("stops generation after a credit-blocked knowledge lookup", async () => {
    mocks.lookup.mockRejectedValue(new KnowledgeLookupError(402, chatErrorMessage("Not enough credits")));
    const response = await handleChat(request([{ id: "u1", role: "user", parts: [{ type: "text", text: "PDPL" }] }]));
    expect(response.status).toBe(402);
    expect(mocks.createCall).not.toHaveBeenCalled();
  });

  it("does not silently answer when the knowledge database is unavailable", async () => {
    mocks.lookup.mockRejectedValue(new KnowledgeLookupError(503, "Knowledge unavailable"));
    const response = await handleChat(request([{ id: "u1", role: "user", parts: [{ type: "text", text: "PDPL" }] }]));
    expect(response.status).toBe(503);
    expect(mocks.createCall).not.toHaveBeenCalled();
  });

  it("includes retrieved knowledge and prior user and assistant text in a follow-up", async () => {
    mocks.lookup.mockResolvedValue("[مرجع الامتثال - PDPL]\nاختبار استرجاع المعرفة");
    await handleChat(request([
      { id: "u1", role: "user", parts: [{ type: "text", text: "اسم المبادرة موجة ألف" }] },
      { id: "a1", role: "assistant", parts: [{ type: "text", text: "موجة ألف" }] },
      { id: "u2", role: "user", parts: [{ type: "text", text: "ما اسمها وما متطلبات PDPL؟" }] },
    ]));
    expect(mocks.lookup).toHaveBeenCalledWith("test-only", "ما اسمها وما متطلبات PDPL؟");
    const call = mocks.createCall.mock.calls[0];
    expect(call?.[2]).toEqual([
      { role: "user", content: [{ type: "text", text: "اسم المبادرة موجة ألف" }] },
      { role: "assistant", content: [{ type: "text", text: "موجة ألف" }] },
      { role: "user", content: [{ type: "text", text: "ما اسمها وما متطلبات PDPL؟" }] },
    ]);
    expect(call?.[3]).toContain("[مرجع الامتثال - PDPL]\nاختبار استرجاع المعرفة");
  });
});