import { QueryClient } from "@tanstack/react-query";
import { createRouter, rootRouteId } from "@tanstack/react-router";
import { describe, expect, it } from "vitest";

import { routeTree } from "@/routeTree.gen";
import { mainNavigation, projectSectionIndexes } from "@/components/presentation/navigation";

// Match routes without running loaders or rendering: loaders may need a server or
// network the test run lacks, and jsdom never loads the stylesheets React waits on.
describe("App routing", () => {
  it("groups sections 1–6 and 8 together, excluding digital documentation", () => {
    expect([...projectSectionIndexes]).toEqual([0, 1, 2, 3, 4, 5, 7]);
  });

  it("provides separate project, documentation and assistant destinations", () => {
    expect(mainNavigation.map((item) => item.path)).toEqual(["/", "/digital-doc", "/assistant"]);
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });
    expect(router.matchRoutes("/assistant").at(-1)?.routeId).toBe("/assistant");
  });

  it("matches a page for / instead of falling back to not found", () => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });

    const matches = router.matchRoutes("/");

    expect(matches.at(-1)?.routeId).not.toBe(rootRouteId);
  });
});
