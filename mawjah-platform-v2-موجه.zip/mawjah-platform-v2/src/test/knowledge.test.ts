import { describe, it, expect } from "vitest";
import { chunkText } from "@/lib/memory.server";
describe("chunkText", () => {
  it("covers the whole document with overlapping chunks", () => {
    const text = "أ".repeat(3000);
    const chunks = chunkText(text);
    expect(chunks.length).toBe(3);
    expect(chunks.every((c) => c.length <= 1200)).toBe(true);
  });
});
