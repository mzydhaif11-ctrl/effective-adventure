import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Award } from "lucide-react";
import { Button } from "@/components/ui/button";
import { issueCertificate } from "@/lib/certificates.functions";

type Cert = { certificateNumber: string; sha256: string; timestamp: string };

export function CertificateForm() {
  const issue = useServerFn(issueCertificate);
  const [cert, setCert] = useState<Cert>();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const field = "mt-1 w-full rounded-md border border-border bg-background p-3 text-sm";
  return (
    <form
      className="mt-9 rounded-lg border border-border p-5"
      onSubmit={async (e) => {
        e.preventDefault();
        const f = new FormData(e.currentTarget);
        setBusy(true); setError(""); setCert(undefined);
        try {
          setCert(await issue({ data: { title: String(f.get("title")), ownerName: String(f.get("owner")), ideaText: String(f.get("idea")) } }));
        } catch {
          setError("تعذر إصدار الشهادة. تأكد أن العنوان 3 أحرف والفكرة 20 حرفًا على الأقل.");
        } finally { setBusy(false); }
      }}
    >
      <h2 className="flex items-center gap-2 text-xl font-bold"><Award className="text-primary" />إصدار شهادة إيداع فكرة</h2>
      <p className="mt-2 text-sm text-muted-foreground">تُحسب بصمة SHA-256 للفكرة وتُحفظ برقم شهادة. لا يُحفظ نص الفكرة نفسه.</p>
      <label className="mt-4 block text-sm">عنوان الفكرة<input name="title" required className={field} /></label>
      <label className="mt-3 block text-sm">اسم صاحب الفكرة<input name="owner" required className={field} /></label>
      <label className="mt-3 block text-sm">نص الفكرة<textarea name="idea" required rows={4} className={field} /></label>
      <Button type="submit" className="mt-4" disabled={busy}>{busy ? "جارٍ الإصدار…" : "إصدار الشهادة"}</Button>
      {cert && <div role="status" className="mt-4 rounded-lg bg-success/10 p-4 text-success"><b>رقم الشهادة: <span dir="ltr">{cert.certificateNumber}</span></b><code dir="ltr" className="mt-2 block break-all text-xs">{cert.sha256}</code><span className="mt-1 block text-xs">{new Date(cert.timestamp).toLocaleString("ar-SA")}</span></div>}
      {error && <p role="alert" className="mt-4 text-destructive">{error}</p>}
    </form>
  );
}
