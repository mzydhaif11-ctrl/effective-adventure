import { useRef, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { uploadKnowledgeDocument } from "@/lib/knowledge.functions";

export function KnowledgeUpload() {
  const upload = useServerFn(uploadKnowledgeDocument);
  const inputRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const onFile = async (file?: File) => {
    if (!file) return;
    setMsg(null);
    if (file.size > 200000) return setMsg({ ok: false, text: "الملف أكبر من 200 كيلوبايت." });
    setBusy(true);
    try {
      const text = await file.text();
      const res = await upload({ data: { name: file.name, text } });
      setMsg(res.ok ? { ok: true, text: `أُضيف «${file.name}» (${res.chunks} جزء). يمكنك السؤال عنه الآن.` } : { ok: false, text: res.error });
    } catch {
      setMsg({ ok: false, text: "تعذر قراءة الملف. استخدم ملفًا نصيًا (txt أو md أو csv)." });
    } finally {
      setBusy(false);
      if (inputRef.current) inputRef.current.value = "";
    }
  };

  return <div className="shrink-0 border-b border-border px-3 py-2 text-xs">
    <input ref={inputRef} type="file" accept=".txt,.md,.csv,.json,text/plain,text/markdown" className="hidden" aria-label="اختر مستندًا" onChange={(e) => void onFile(e.target.files?.[0])} />
    <div className="flex flex-wrap items-center gap-2">
      <Button variant="outline" size="sm" disabled={busy} onClick={() => inputRef.current?.click()}><Upload />{busy ? "جارٍ الرفع…" : "رفع مستند للمعرفة"}</Button>
      <span className="text-muted-foreground">ملفات نصية: txt، md، csv</span>
    </div>
    {msg && <p role="status" className={msg.ok ? "mt-2 text-foreground" : "mt-2 text-destructive"}>{msg.text}</p>}
  </div>;
}
