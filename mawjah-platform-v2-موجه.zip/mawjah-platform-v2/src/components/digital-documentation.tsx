import { useState } from "react";
import { Copy, Check, Upload, Fingerprint } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CertificateForm } from "@/components/certificate-form";
import { DOCUMENT_HASH } from "@/lib/mawjah-knowledge";

export function DigitalDocumentation() {
  const [result, setResult] = useState<string>();
  const [error, setError] = useState("");
  const [copied, setCopied] = useState(false);
  const [filename, setFilename] = useState("");
  return <div className="documentation-body">
    <div className="flex items-center gap-3 text-success"><Fingerprint /><span>SHA-256 / التحقق التقني</span></div>
    <h1 className="mt-4 text-3xl font-bold md:text-5xl">التوثيق الرقمي</h1>
    <p className="mt-5 max-w-2xl leading-8 text-muted-foreground">بصمة الوثيقة كما قدمها صاحب المقترح. مطابقة البصمة تثبت تطابق محتوى الملف فقط، ولا تثبت ملكية أو اعتمادًا حكوميًا.</p>
    <dl className="my-8 grid gap-6 border-y border-border py-6 sm:grid-cols-2"><div><dt className="text-sm text-muted-foreground">معرّف الوثيقة</dt><dd className="mt-2 break-all font-mono" dir="ltr">DOC-MWG-2026-005-FULL</dd></div><div><dt className="text-sm text-muted-foreground">صاحب المقترح</dt><dd className="mt-2 font-bold">مزيد هايف الرفعان الرشيدي</dd></div></dl>
    <div className="hash-tool rounded-lg border border-border bg-muted p-5"><div className="flex items-center justify-between"><h2 className="font-bold">البصمة المقدّمة</h2><Button size="icon" variant="outline" title="نسخ البصمة" aria-label="نسخ البصمة" onClick={async () => { try { await navigator.clipboard.writeText(DOCUMENT_HASH); setCopied(true); } catch { setError("تعذر النسخ؛ يمكنك تحديد البصمة ونسخها."); } }}>{copied ? <Check /> : <Copy />}</Button></div><code dir="ltr" className="mt-4 block break-all font-mono text-sm leading-7">{DOCUMENT_HASH}</code></div>
    <label className="mt-6 flex cursor-pointer flex-col items-center gap-3 rounded-lg border border-dashed border-border p-6 text-center"><Upload className="text-muted-foreground" /><span className="font-bold">اختيار ملف للتحقق</span><span className="text-sm text-muted-foreground">{filename || "يُحسب محليًا دون رفعه إلى الخادم"}</span><input type="file" aria-label="اختيار ملف للتحقق" className="sr-only" onChange={async (event) => {
      const file = event.target.files?.[0]; if (!file) return;
      setError(""); setResult(undefined); setFilename(file.name);
      try { const digest = await crypto.subtle.digest("SHA-256", await file.arrayBuffer()); setResult(Array.from(new Uint8Array(digest), (b) => b.toString(16).padStart(2, "0")).join("")); } catch { setError("تعذر حساب بصمة هذا الملف."); }
    }} /></label>
    {result && <div role="status" className={`mt-4 rounded-lg p-4 ${result === DOCUMENT_HASH ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"}`}><b>{result === DOCUMENT_HASH ? "مطابقة — المحتوى متطابق" : "غير مطابقة للبصمة المقدّمة"}</b><code dir="ltr" className="mt-2 block break-all text-xs">{result}</code></div>}
    {error && <p role="alert" className="mt-4 text-destructive">{error}</p>}
    <h2 className="mt-9 text-xl font-bold">البصمة والتوقيع</h2><p className="mt-3 leading-8 text-muted-foreground">توقيع صاحب المقترح: مزيد الرفعان (نصي). ليس شهادة توقيع تشفيري معتمدة. الحالة: توثيق داخلي للتقييم — INTERNAL — FOR EVALUATION.</p>
    <p className="mt-4 border-r-2 border-primary pr-4 leading-7 text-muted-foreground">لا توجد أختام أو توقيعات منسوبة إلى سدايا أو أي جهة خارجية. أسماء النماذج والأدوات وصف تقني مقترح فقط.</p>
    <CertificateForm />
  </div>;
}