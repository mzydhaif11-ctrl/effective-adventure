import { Link, useRouterState } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { Menu, X, ChevronLeft, ChevronRight, Maximize, Minimize, Printer, StickyNote } from "lucide-react";
import { Button } from "@/components/ui/button";
import { slides, SlideContent } from "./slides";
import { ScaledSlide } from "./scaled-slide";
import { DigitalDocumentation } from "@/components/digital-documentation";
import { mainNavigation, projectSectionIndexes } from "./navigation";
import { ProjectOverview } from "./project-overview";

export function DeckShell({ active = 0, children }: { active?: number; children?: ReactNode }) {
  const pathname = useRouterState({ select: (state) => state.location.pathname });
  const isAssistant = pathname === "/assistant";
  const isDigital = active === 6;
  const [menu, setMenu] = useState(false);
  const [presenting, setPresenting] = useState(false);
  const [position, setPosition] = useState(0);
  const [notesOpen, setNotesOpen] = useState(false);
  const [notes, setNotes] = useState("");
  const slideIndex = projectSectionIndexes[position] ?? 0;
  useEffect(() => {
    const fullscreen = () => setPresenting(Boolean(document.fullscreenElement));
    document.addEventListener("fullscreenchange", fullscreen);
    return () => document.removeEventListener("fullscreenchange", fullscreen);
  }, []);
  useEffect(() => {
    const key = (event: KeyboardEvent) => {
      if (event.target instanceof HTMLElement && event.target.closest("input,textarea,[contenteditable=true]")) return;
      if (event.key === "Escape") { setMenu(false); setPresenting(false); }
      if (!presenting) return;
      if (event.key === "ArrowLeft" || event.key === " ") { event.preventDefault(); setPosition((value) => Math.min(projectSectionIndexes.length - 1, value + 1)); }
      if (event.key === "ArrowRight") { event.preventDefault(); setPosition((value) => Math.max(0, value - 1)); }
    };
    window.addEventListener("keydown", key);
    return () => window.removeEventListener("keydown", key);
  }, [presenting]);
  const fullscreen = async () => {
    if (presenting) { if (document.fullscreenElement) await document.exitFullscreen(); setPresenting(false); }
    else { setMenu(false); setPresenting(true); try { await document.documentElement.requestFullscreen(); } catch { /* Keep page presentation available. */ } }
  };
  return <div className={`presentation-app ${presenting ? "is-presenting" : ""} ${isAssistant ? "assistant-app" : ""}`} dir="rtl">
    <header className="presentation-toolbar"><div className="flex min-w-0 items-center gap-3"><Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setMenu(!menu)} aria-label={menu ? "إغلاق القائمة" : "فتح القائمة"} aria-expanded={menu} aria-controls="main-menu" title="القائمة">{menu ? <X /> : <Menu />}</Button><span className="brand-mark">م</span><div><strong>موجة V2</strong><p className="text-xs text-muted-foreground">{isAssistant ? "المساعد الذكي" : isDigital ? "التوثيق الرقمي" : "عرض المقترح التقني"}</p></div></div>{!isAssistant && !isDigital && <div className="flex items-center gap-1"><Button variant="ghost" size="icon" title="ملاحظات العرض" aria-label="ملاحظات العرض" onClick={() => setNotesOpen(!notesOpen)}><StickyNote /></Button><Button variant="ghost" size="icon" title="طباعة العرض" aria-label="طباعة العرض" onClick={() => window.open("/?print=true", "_blank", "noopener")}><Printer /></Button><Button onClick={() => void fullscreen()}><Maximize /><span className="hidden sm:inline">بدء العرض</span></Button></div>}</header>
    {menu && <div className="menu-scrim" onClick={() => setMenu(false)} />}
    <aside id="main-menu" className={`presentation-sidebar ${menu ? "menu-open" : ""}`}><p className="sidebar-caption">القائمة الرئيسية</p><nav aria-label="القائمة الرئيسية">{mainNavigation.map((item) => {
      const selected = item.path === "/" ? !isAssistant && !isDigital : pathname === item.path;
      return <Button key={item.path} asChild variant="ghost" className={`sidebar-slide ${selected ? "selected" : ""}`}><Link to={item.path} onClick={() => setMenu(false)} aria-current={selected ? "page" : undefined}><item.icon aria-hidden="true" /><span>{item.title}</span></Link></Button>;
    })}</nav><div className="sidebar-status"><span className="status-dot" />توثيق داخلي للتقييم<p>DOC-MWG-2026-005-FULL</p></div></aside>
    <main className="presentation-workspace">
      {isAssistant ? children : isDigital ? <DigitalDocumentation /> : presenting ? <><div className="presentation-canvas"><ScaledSlide><SlideContent index={slideIndex} /></ScaledSlide></div><div className="presentation-controls"><Button variant="outline" size="icon" aria-label="الشريحة السابقة" disabled={position === 0} onClick={() => setPosition(position - 1)}><ChevronRight /></Button><span>{position + 1} / {projectSectionIndexes.length}</span><Button variant="outline" size="icon" aria-label="الشريحة التالية" disabled={position === projectSectionIndexes.length - 1} onClick={() => setPosition(position + 1)}><ChevronLeft /></Button></div></> : <><ProjectOverview />{notesOpen && <div className="presenter-notes"><label htmlFor="presenter-notes" className="text-sm font-bold">ملاحظات مقدم العرض</label><textarea id="presenter-notes" value={notes} onChange={(event) => setNotes(event.target.value)} placeholder="ملاحظات العرض…" /></div>}</>}
    </main>
    {presenting && <Button className="exit-presentation" variant="outline" size="icon" title="إنهاء العرض" aria-label="إنهاء العرض" onClick={() => void fullscreen()}><Minimize /></Button>}
  </div>;
}
