import { FileText, MessagesSquare, LibraryBig, Workflow, UserRoundCheck, ShieldCheck, Fingerprint, CircleCheck } from "lucide-react";

export const slides = [
  { id: "intro", title: "عرض المشروع", path: "/", description: "فكرة وطنية طموحة تبدأ بنموذج أولي لحفظ أثر الابتكار وتبادل المعرفة.", kicker: "موجة / العرض التنفيذي", heading: "منصة موجة V2", text: "فكرة وطنية طموحة تبدأ بنموذج أولي.", bullets: ["حفظ أثر الابتكار وتبادل المعرفة", "استكشاف الأتمتة والتكامل المؤسسي", "مقترح داخلي للتقييم، وليس اعتمادًا حكوميًا"], icon: Workflow },
  { id: "brief", title: "الملخص التنفيذي", path: "/brief", description: "تصور تقني لتحويل الأفكار والمستندات المتفرقة إلى معرفة قابلة للمراجعة.", kicker: "01 / من الفكرة إلى الأثر", heading: "معرفة منظّمة. أثر قابل للتتبّع.", text: "تصور تقني لمعالجة فجوة الأفكار والمستندات المتفرقة، وتحويلها إلى معرفة قابلة للمراجعة والتقييم.", bullets: ["توثيق أصل المقترح وبصمته", "تنظيم المعرفة المؤسسية", "تقييم بشري قبل التنفيذ"], icon: LibraryBig },
  { id: "goals", title: "الأهداف الاستراتيجية", path: "/goals", description: "أهداف مقترحة لقياس الأثر في تجربة محدودة قبل أي تعميم.", kicker: "02 / الأثر المستهدف", heading: "وقت أقل. معرفة أوضح.", text: "أهداف مقترحة تحتاج قياسًا واختبارًا في تجربة محدودة، وليست نتائج مثبتة.", bullets: ["حتى 70% تقليص مستهدف لوقت معالجة المستندات والطلبات", "لوحات مؤشرات وتحليلات تدعم القرار", "خصوصية وسيادة رقمية وفق الضوابط المعتمدة"], icon: CircleCheck },
  { id: "architecture", title: "المكونات المعمارية", path: "/architecture", description: "تكامل مرحلي عبر واجهات وصلاحيات تعتمدها الجهة المختصة.", kicker: "03 / التصور التقني", heading: "تنسيق ذكي، بإشراف بشري.", text: "تكامل مرحلي عبر واجهات وصلاحيات تعتمدها الجهة المختصة قبل أي تفعيل.", bullets: ["تنسيق الطلبات والمهام بين الخدمات", "نماذج هجينة لتحليل النصوص والبيانات", "حوكمة وصلاحيات وسجلات تدقيق"], icon: Workflow },
  { id: "usecases", title: "حالات الاستخدام", path: "/usecases", description: "معالجة المستندات، أتمتة خدمة المستفيدين، ومساعد المعرفة المؤسسية.", kicker: "04 / القطاع الحكومي", heading: "ثلاثة مسارات عالية الأثر.", text: "حالات تشغيل مقترحة لتجربة محدودة، بعد تحديد البيانات والضوابط والصلاحيات.", bullets: ["معالجة المستندات والتعاميم", "أتمتة خدمة المستفيدين وتحليل الطلبات والشكاوى", "مساعد المعرفة المؤسسية — Enterprise Knowledge Base"], icon: MessagesSquare },
  { id: "human", title: "المراجعة البشرية", path: "/human-review", description: "لا قرار حساس نهائيًا بشكل تلقائي؛ المسؤولية لدى الموظف المختص.", kicker: "05 / الإنسان صاحب القرار", heading: "اقتراح آلي. اعتماد بشري.", text: "لا يُتخذ أي قرار حساس نهائيًا بشكل تلقائي؛ تبقى المسؤولية لدى الموظف المختص.", bullets: ["النظام يحلل ويقترح", "الموظف يراجع ثم يعتمد أو يرفض", "تسجيل القرار وسياقه للتدقيق"], icon: UserRoundCheck },
  { id: "digital", title: "التوثيق الرقمي", path: "/digital-doc", description: "بصمة SHA-256 للتحقق من تطابق الملف مع القيمة المقدمة.", kicker: "06 / سلامة المحتوى", heading: "بصمة واضحة للمقترح.", text: "بصمة SHA-256 للتحقق من تطابق الملف مع القيمة المقدمة؛ لا تثبت وحدها الملكية أو اعتماد التوقيع.", bullets: ["معرّف الوثيقة DOC-MWG-2026-005-FULL", "بصمة من 64 رمزًا", "توقيع صاحب المقترح نصي، وليس شهادة توقيع معتمدة"], icon: Fingerprint },
  { id: "status", title: "حالة الوثيقة", path: "/status", description: "توثيق داخلي للتقييم فقط؛ الاعتماد الرسمي من الجهة المختصة.", kicker: "07 / المسؤولية والحدود", heading: "توثيق داخلي. للتقييم فقط.", text: "مقدم المقترح: مزيد هايف الرفعان الرشيدي. لا توجد شراكة أو موافقة أو ربط حكومي مثبت.", bullets: ["الاعتماد الرسمي يصدر حصريًا من الجهة المختصة", "أسماء النماذج والأدوات وصف تقني مقترح فقط", "أي تفعيل لاحق مشروط بالموافقات ومراجعة الامتثال"], icon: ShieldCheck },
] as const;

export type SlidePath = (typeof slides)[number]["path"];

export function SlideContent({ index }: { index: number }) {
  const slide = slides[index] ?? slides[0];
  if (!slide) return null;
  const Icon = slide.icon;
  return <article className={`slide-content ${index === 0 ? "slide-cover" : ""}`} dir="rtl">
    <header className="slide-top"><span className="slide-kicker">{slide.kicker}</span><span className="slide-chrome">MAWJAH / V2</span></header>
    <div className="slide-main">
      <div className="slide-copy"><h1 className="slide-title">{slide.heading}</h1><p className="slide-body-lg">{slide.text}</p><ul className="slide-points">{slide.bullets.map((text, i) => <li key={text}><span className="slide-point-number">0{i + 1}</span><span className="slide-body">{text}</span></li>)}</ul></div>
      <div className="slide-visual"><div className="slide-symbol"><Icon strokeWidth={1} aria-hidden="true" /></div><div className="slide-network"><span><FileText />المستندات</span><i /><span><LibraryBig />المعرفة</span><i /><span><UserRoundCheck />المراجعة</span></div><p className="slide-caption">موجة · تصور تقني قابل للتقييم</p></div>
    </div>
    <footer className="slide-bottom"><span className="slide-footer">مزيد هايف الرفعان الرشيدي · توثيق داخلي للتقييم</span><span className="slide-page">{String(index + 1).padStart(2, "0")} / {String(slides.length).padStart(2, "0")}</span></footer>
  </article>;
}
