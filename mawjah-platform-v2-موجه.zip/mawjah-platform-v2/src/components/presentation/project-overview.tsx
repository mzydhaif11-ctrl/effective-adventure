import { slides } from "./slides";
import { projectSectionIndexes } from "./navigation";

export function ProjectOverview() {
  return <div className="project-overview">
    {projectSectionIndexes.map((index) => {
      const slide = slides[index];
      const Icon = slide.icon;
      return <section key={slide.id} id={slide.id} className={`project-section ${index === 0 ? "project-intro" : ""}`} aria-labelledby={`heading-${slide.id}`}>
        <div className="project-section-label"><Icon aria-hidden="true" /><span>{slide.title}</span></div>
        <div className="project-section-copy">
          {index === 0 ? <h1 id={`heading-${slide.id}`}>{slide.heading}</h1> : <h2 id={`heading-${slide.id}`}>{slide.heading}</h2>}
          <p>{slide.text}</p>
          <ul>{slide.bullets.map((bullet) => <li key={bullet}>{bullet}</li>)}</ul>
        </div>
      </section>;
    })}
  </div>;
}
