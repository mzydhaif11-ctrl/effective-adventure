import { FileText, Fingerprint, MessageCircle } from "lucide-react";

export const mainNavigation = [
  { title: "عرض المشروع", path: "/", icon: FileText },
  { title: "التوثيق الرقمي", path: "/digital-doc", icon: Fingerprint },
  { title: "المساعد الذكي", path: "/assistant", icon: MessageCircle },
] as const;

export const projectSectionIndexes = [0, 1, 2, 3, 4, 5, 7] as const;
