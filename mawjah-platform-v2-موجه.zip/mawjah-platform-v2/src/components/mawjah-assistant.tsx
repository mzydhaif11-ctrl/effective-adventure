import { useEffect, useRef, useState } from "react";
import { useChat } from "@ai-sdk/react";
import { DefaultChatTransport } from "ai";
import { RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Conversation, ConversationContent, ConversationScrollButton } from "@/components/ai-elements/conversation";
import { Message, MessageContent, MessageResponse } from "@/components/ai-elements/message";
import { PromptInput, PromptInputTextarea, PromptInputFooter, PromptInputSubmit } from "@/components/ai-elements/prompt-input";
import { Shimmer } from "@/components/ai-elements/shimmer";
import { Reasoning, ReasoningTrigger, ReasoningContent } from "@/components/ai-elements/reasoning";
import { chatErrorMessage } from "@/lib/chat-error";
import { KnowledgeUpload } from "@/components/knowledge-upload";

const transport = new DefaultChatTransport({ api: "/api/chat" });

export function MawjahAssistant() {
  const [input, setInput] = useState("");
  const textarea = useRef<HTMLTextAreaElement>(null);
  const { messages, sendMessage, status, stop, error, clearError, setMessages } = useChat({ transport });
  const busy = status === "submitted" || status === "streaming";
  useEffect(() => { if (!busy && window.matchMedia("(pointer: fine)").matches) textarea.current?.focus({ preventScroll: true }); }, [busy]);
  const send = async (text: string) => {
    if (!text.trim() || busy) return;
    clearError();
    setInput("");
    await sendMessage({ text: text.trim() });
    if (window.matchMedia("(pointer: fine)").matches) textarea.current?.focus({ preventScroll: true });
  };
  return <section id="mawjah-chat" aria-label="مساعد موجة" className="assistant-full-page flex min-h-0 flex-col overflow-hidden bg-card text-card-foreground" dir="rtl">
      <header className="flex shrink-0 items-center justify-between gap-2 border-b border-border p-3">
        <div className="flex min-w-0 items-center gap-3"><span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-primary font-bold text-primary-foreground">م</span><div><h1 className="font-bold">المساعد الذكي</h1><p className="text-xs text-muted-foreground">المقترح والحوكمة · للجلسة الحالية</p></div></div>
        <div className="flex gap-1"><Button variant="ghost" size="icon" title="محادثة جديدة" aria-label="محادثة جديدة" disabled={busy} onClick={() => { setMessages([]); clearError(); }}><RotateCcw /></Button></div>
      </header>
      <KnowledgeUpload />
      <Conversation className="min-h-0 flex-1"><ConversationContent className="gap-5 p-4">
        {messages.length === 0 && <Message from="assistant"><MessageContent><MessageResponse>مرحبًا، أنا مساعد موجة. ما الذي ترغب بمعرفته عن المقترح أو الحوكمة؟</MessageResponse></MessageContent></Message>}
        {messages.map((message) => <Message key={message.id} from={message.role}><MessageContent className="min-w-0 max-w-full break-words text-sm leading-7">
          {message.parts.map((part, index) => part.type === "text" ? <MessageResponse key={index}>{part.text}</MessageResponse> : part.type === "reasoning" && part.text ? <Reasoning key={index} defaultOpen={false} isStreaming={busy && message.id === messages.at(-1)?.id}><ReasoningTrigger>ملخص التفكير</ReasoningTrigger><ReasoningContent>{part.text}</ReasoningContent></Reasoning> : null)}
        </MessageContent></Message>)}
        {status === "submitted" && <Shimmer className="text-sm">جارٍ إعداد الرد…</Shimmer>}
      </ConversationContent><ConversationScrollButton /></Conversation>
      {error && <div role="alert" className="shrink-0 border-t border-border p-3 text-sm text-destructive">{chatErrorMessage(error.message)}</div>}
      {messages.length === 0 && <div className="flex shrink-0 flex-wrap gap-2 px-3 pb-3">{["لخص المقترح", "دور المراجعة البشرية", "كيف أربط ChromaDB؟"].map((text) => <Button key={text} variant="outline" size="sm" onClick={() => void send(text)}>{text}</Button>)}</div>}
      <div className="shrink-0 border-t border-border p-3"><PromptInput onSubmit={({ text }) => send(text)}><PromptInputTextarea ref={textarea} value={input} onChange={(event) => setInput(event.target.value)} placeholder="اكتب سؤالك…" aria-label="سؤالك للمساعد" className="min-h-16 text-base" /><PromptInputFooter className="justify-end"><PromptInputSubmit status={status} disabled={!busy && !input.trim()} onStop={() => void stop()} aria-label={busy ? "إيقاف الرد" : "إرسال السؤال"} title={busy ? "إيقاف الرد" : "إرسال السؤال"} className="size-10" /></PromptInputFooter></PromptInput></div>
    </section>;
}