import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const input = z.object({
  name: z.string().trim().min(1).max(200),
  text: z.string().trim().min(20).max(200000),
});

export const uploadKnowledgeDocument = createServerFn({ method: "POST" })
  .inputValidator((d) => input.parse(d))
  .handler(async ({ data }) => {
    const apiKey = process.env["LOVABLE_API_KEY"];
    if (!apiKey) return { ok: false as const, error: "خدمة المعرفة غير مهيأة بعد." };
    const { indexDocument } = await import("./memory.server");
    try {
      const chunks = await indexDocument(apiKey, data.name, data.text);
      return { ok: true as const, chunks };
    } catch (e) {
      console.error("document upload failed", e);
      return { ok: false as const, error: e instanceof Error ? e.message : "تعذر رفع المستند." };
    }
  });
