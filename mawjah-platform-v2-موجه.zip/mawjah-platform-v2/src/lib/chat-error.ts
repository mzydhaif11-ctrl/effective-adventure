/** Translate the known gateway credit error without hiding other safe messages. */
export function chatErrorMessage(message: string): string {
  if (/not enough credits|insufficient credits|payment required/i.test(message)) {
    return "رصيد الذكاء الاصطناعي غير كافٍ. يلزم إضافة رصيد إلى Lovable لاستئناف الإجابات واسترجاع المعرفة.";
  }
  return message || "تعذر الاتصال بالمساعد.";
}

export class KnowledgeLookupError extends Error {
  constructor(public readonly status: number, message: string) {
    super(message);
    this.name = "KnowledgeLookupError";
  }
}