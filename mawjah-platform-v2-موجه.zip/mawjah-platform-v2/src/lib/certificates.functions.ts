import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const input = z.object({
  title: z.string().trim().min(3).max(200),
  ownerName: z.string().trim().min(2).max(120),
  ideaText: z.string().trim().min(20).max(20000),
});

export const issueCertificate = createServerFn({ method: "POST" })
  .inputValidator((d) => input.parse(d))
  .handler(async ({ data }) => {
    const bytes = new TextEncoder().encode(`${data.title}\n${data.ownerName}\n${data.ideaText}`);
    const digest = await crypto.subtle.digest("SHA-256", bytes);
    const hash = [...new Uint8Array(digest)].map((b) => b.toString(16).padStart(2, "0")).join("");
    const number = `MWG-${new Date().getFullYear()}-${hash.slice(0, 8).toUpperCase()}`;
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: existing } = await supabaseAdmin.from("certificates").select("certificate_number, sha256_hash, created_at").eq("sha256_hash", hash).maybeSingle();
    if (existing) return { certificateNumber: existing.certificate_number, sha256: existing.sha256_hash, timestamp: existing.created_at };
    const { data: row, error } = await supabaseAdmin
      .from("certificates")
      .insert({ certificate_number: number, title: data.title, owner_name: data.ownerName, sha256_hash: hash })
      .select("certificate_number, sha256_hash, created_at")
      .single();
    if (error) throw new Error("تعذر إصدار الشهادة");
    return { certificateNumber: row.certificate_number, sha256: row.sha256_hash, timestamp: row.created_at };
  });
