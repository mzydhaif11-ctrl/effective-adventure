// Knowledge memory (replaces the ChromaDB rag_service.py): pgvector + gateway embeddings.
import { chatErrorMessage, KnowledgeLookupError } from "./chat-error";
const EMBED_URL = "https://ai.gateway.lovable.dev/v1/embeddings";
const EMBED_MODEL = "google/gemini-embedding-2";

export function chunkText(text: string, size = 1200, overlap = 150): string[] {
  const clean = text.replace(/\r/g, "").replace(/\n{3,}/g, "\n\n").trim();
  const chunks: string[] = [];
  for (let i = 0; i < clean.length; i += size - overlap) {
    const part = clean.slice(i, i + size).trim();
    if (part) chunks.push(part);
    if (i + size >= clean.length) break;
  }
  return chunks;
}

/** Index an uploaded document: chunk, embed every chunk, store. */
export async function indexDocument(apiKey: string, source: string, text: string): Promise<number> {
  const chunks = chunkText(text);
  const db = await admin();
  for (let i = 0; i < chunks.length; i += 32) {
    const batch = chunks.slice(i, i + 32);
    const vectors = await embed(apiKey, batch);
    const { error } = await db.from("knowledge_chunks").insert(batch.map((content, j) => ({ source, section: `جزء ${i + j + 1}`, content, embedding: JSON.stringify(vectors[j]) })));
    if (error) throw new Error("تعذر حفظ المستند في قاعدة المعرفة.");
  }
  return chunks.length;
}

async function embed(apiKey: string, inputs: string[]): Promise<number[][]> {
  const res = await fetch(EMBED_URL, {
    method: "POST",
    headers: { Authorization: `Bearer ${apiKey}`, "Content-Type": "application/json", "X-Lovable-AIG-SDK": "fetch" },
    body: JSON.stringify({ model: EMBED_MODEL, input: inputs }),
  });
  if (!res.ok) {
    const payload = await res.json().catch(() => ({})) as { message?: string; error?: { message?: string } };
    throw new KnowledgeLookupError(res.status, chatErrorMessage(payload.message ?? payload.error?.message ?? "تعذر استرجاع المعرفة. الخدمة غير متاحة حاليًا."));
  }
  const json = (await res.json()) as { data: { embedding: number[]; index: number }[] };
  return json.data.sort((a, b) => a.index - b.index).map((d) => d.embedding);
}

async function admin() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  return supabaseAdmin;
}

async function backfill(apiKey: string) {
  const db = await admin();
  const { data, error } = await db.from("knowledge_chunks").select("id, content").is("embedding", null).limit(32);
  if (error) throw new Error("Knowledge index unavailable");
  if (!data?.length) return;
  const vectors = await embed(apiKey, data.map((d) => d.content));
  const results = await Promise.all(data.map((d, i) => db.from("knowledge_chunks").update({ embedding: JSON.stringify(vectors[i]) }).eq("id", d.id)));
  if (results.some((result) => result.error)) throw new Error("Knowledge indexing failed");
}

/** Equivalent of get_context_for_prompt(): returns top-3 related chunks as text. */
export async function getContextForPrompt(apiKey: string, query: string): Promise<string> {
  try {
    await backfill(apiKey);
    const [vector] = await embed(apiKey, [query.slice(0, 4000)]);
    const db = await admin();
    const { data, error } = await db.rpc("match_knowledge", { query_embedding: JSON.stringify(vector), match_count: 3 });
    if (error) throw new Error("Knowledge search failed");
    if (!data?.length) return "";
    return data.map((r) => `[${r.source} - ${r.section}]\n${r.content}`).join("\n\n---\n\n");
  } catch (e) {
    console.error("memory lookup failed", e);
    if (e instanceof KnowledgeLookupError) throw e;
    throw new KnowledgeLookupError(503, "تعذر استرجاع قاعدة المعرفة حاليًا؛ لم يُنشأ رد دونها.");
  }
}
