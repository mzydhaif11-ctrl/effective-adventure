<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep the Mawjah assistant in a dedicated component and stream through a TanStack server route with server-only gateway helpers, so credentials never enter the browser.
- The assistant resends all user/assistant text for one session-only conversation, dropping prior reasoning items; this preserves conversational context without claiming durable memory.
- Presentation content shares a central slide registry and semantic tokens; normal project viewing renders all project sections together, while fullscreen and print reuse the 1920×1080 slide renderer.
- Main navigation uses one shared registry for project, documentation and assistant pages; legacy section URLs retain the consolidated project view to preserve existing links.
- Render the existing session-only assistant inside the dedicated assistant route and shared shell, not a floating dialog, so the main menu owns navigation.
- Knowledge retrieval failures must end the chat request with their safe status and message before generation; never silently replace unavailable retrieval with a general answer or continue a blocked AI call chain.
